import React from 'react'

export default function AITravelPlannerPage() {
  return (
    <div className='  flex  justify-center mt-10'>
        <h1 className='text-xl font-semibold text-gray-800'>
            Something new ComingSoon...
        </h1>
    </div>
  )
}


